package g33_ceng211_hw3;

public class IndefiniteGame extends Game {
	
	private int minimumEvaluationTime; //In Hour

	public IndefiniteGame(int arrivalDay, String name, double averageRating, int minimumEvaluationTime) {
		super(arrivalDay, name, averageRating);
		this.minimumEvaluationTime = minimumEvaluationTime;
	}

	@Override
	public double calculateRating(double criticsOpinion) {
		double ratingCalcOfCritics = this.getAverageRating() + ((10 - this.minimumEvaluationTime) * 0.25) + (criticsOpinion);
		return ratingCalcOfCritics;
	}

	public int getMinimumEvaluationTime() {
		return minimumEvaluationTime;
	}

	public void setMinimumEvaluationTime(int minimumEvaluationTime) {
		this.minimumEvaluationTime = minimumEvaluationTime;
	}

	
}
