package g33_ceng211_hw3;

public class CasualGame extends Game {
	
	private int matchDuration; //In Hour

	public CasualGame(int arrivalDay, String name, double averageRating, int matchDuration) {
		super(arrivalDay, name, averageRating);
		this.matchDuration = matchDuration;
	}

	@Override
	public double calculateRating(double criticsOpinion) {
		double ratingCalcOfCritics = this.getAverageRating() + ((this.matchDuration - 3) * 3) + (criticsOpinion);
		return ratingCalcOfCritics;
	}

	public int getMatchDuration() {
		return matchDuration;
	}

	public void setMatchDuration(int matchDuration) {
		this.matchDuration = matchDuration;
	}

}
