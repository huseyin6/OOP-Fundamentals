package g33_ceng211_hw3;

public class ContentRatingCompanyApp {
	
	private static FileIO fileIO = new FileIO();
	
	public static void main(String[] args) {

	}

}
