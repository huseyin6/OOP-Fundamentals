package g33_ceng211_hw3;

public interface IGame {
	
	public double calculateRating(double criticsOpinion);

}
