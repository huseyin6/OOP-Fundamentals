package g33_ceng211_hw3;

public class StoryGame extends Game {
	
	private int storyDuration; //In Hour

	public StoryGame(int arrivalDay, String name, double averageRating, int storyDuration) {
		super(arrivalDay, name, averageRating);
		this.storyDuration = storyDuration;
	}

	@Override
	public double calculateRating(double criticsOpinion) {
		double ratingCalcOfCritics = this.getAverageRating() + (this.storyDuration * 0.25) + (criticsOpinion);
		return ratingCalcOfCritics;
	}

	public int getStoryDuration() {
		return storyDuration;
	}

	public void setStoryDuration(int storyDuration) {
		this.storyDuration = storyDuration;
	}

}
