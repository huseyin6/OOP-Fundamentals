package g33_ceng211_hw3;

public interface IMovie {
	
	public double calculateRating(double criticsOpinion);

}
