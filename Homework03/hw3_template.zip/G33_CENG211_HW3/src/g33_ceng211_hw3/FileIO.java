package g33_ceng211_hw3;

import java.util.Stack;
import java.util.LinkedList;
import java.util.Queue;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileIO {
	
	Stack<Movie> movies = new Stack<Movie>();
	Stack<Game> games = new Stack<Game>();
	
	public void readMovies() {
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader("src/contents.csv"));
			String line = reader.readLine();
			while (line != null) {
				
				line = reader.readLine();
				
			}
			reader.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	

}
