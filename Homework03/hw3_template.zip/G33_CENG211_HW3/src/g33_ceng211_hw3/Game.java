package g33_ceng211_hw3;

public abstract class Game implements IGame {
	
	private int arrivalDay;
	private String name;
	private double averageRating;
	
	public Game(int arrivalDay, String name, double averageRating) {
		super();
		this.arrivalDay = arrivalDay;
		this.name = name;
		this.averageRating = averageRating;
	}
	
	public int getArrivalDay() {
		return arrivalDay;
	}

	public void setArrivalDay(int arrivalDay) {
		this.arrivalDay = arrivalDay;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAverageRating() {
		return averageRating;
	}

	public void setAverageRating(double averageRating) {
		this.averageRating = averageRating;
	}
	
	public abstract double calculateRating(double criticsOpinion);

}
