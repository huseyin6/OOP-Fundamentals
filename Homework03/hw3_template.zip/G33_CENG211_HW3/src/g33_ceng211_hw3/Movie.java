package g33_ceng211_hw3;

public class Movie implements IMovie {
	
	private int arrivalDay;
	private String name;
	private int year;
	private int duration; //In minutes
	private double averageRating;
	
	public Movie(int arrivalDay, String name, int year, int duration, double averageRating) {
		super();
		this.arrivalDay = arrivalDay;
		this.name = name;
		this.year = year;
		this.duration = duration;
		this.averageRating = averageRating;
	}

	public int getArrivalDay() {
		return arrivalDay;
	}

	public void setArrivalDay(int arrivalDay) {
		this.arrivalDay = arrivalDay;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getAverageRating() {
		return averageRating;
	}

	public void setAverageRating(double averageRating) {
		this.averageRating = averageRating;
	}

	@Override
	public double calculateRating(double criticsOpinion) {
		double ratingCalcOfCritics = this.averageRating + ((this.duration - 150) * 0.01) - ((2021 - this.year) * 0.01) + criticsOpinion;
		return ratingCalcOfCritics;
	}
	
}
